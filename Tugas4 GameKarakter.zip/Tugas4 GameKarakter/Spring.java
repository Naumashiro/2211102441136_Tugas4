import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * It's a Spring. Bouncy!
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spring extends Platform
{

}
