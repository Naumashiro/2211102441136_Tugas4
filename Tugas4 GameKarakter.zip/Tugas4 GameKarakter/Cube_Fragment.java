import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Code_Cube_Fragment here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cube_Fragment extends Actor
{
    /**
     * Act - do whatever the Code_Cube_Fragment wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
